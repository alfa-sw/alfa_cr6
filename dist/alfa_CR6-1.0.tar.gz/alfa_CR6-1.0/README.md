## ALFA CR6 1.0.0 

Lanciare l'app dalla sotto cartella alfa_CR6/alfa_CR6/CR6.py
con 

"python3 CR6.py"
